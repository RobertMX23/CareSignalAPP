# CareSignal — Master Data Dictionary v0.1

Diccionario de **623 campos** en el modelo implementado. La base SQLite es la referencia ejecutable.


## `core_contact`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|contact_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|contact_type|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|facility_id|INTEGER||core_facility.facility_id|YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|is_valid|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|organization_id|INTEGER||core_organization.organization_id|YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_id|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_row|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Número de fila original del Excel para lineage.|
|value_normalized|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|value_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Valor fuente limpiado mínimamente; RAW original permanece disponible.|

## `core_facility`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|care_model|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|care_model_other|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|current_status|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|data_confidence|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|facility_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|facility_name|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|facility_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|organization_id|INTEGER||core_organization.organization_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|primary_source_id|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|site_descriptor_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Valor fuente limpiado mínimamente; RAW original permanece disponible.|

## `core_facility_activity`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|activity_id|INTEGER|YES|ref_activity.activity_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|facility_id|INTEGER|YES|core_facility.facility_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_id|TEXT|YES||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_row|INTEGER|YES||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Número de fila original del Excel para lineage.|
|source_value|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||

## `core_facility_service_current`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|available|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|confidence|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|facility_id|INTEGER|YES|core_facility.facility_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|preferred_source_id|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|service_id|INTEGER|YES|ref_service.service_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|

## `core_facility_service_snapshot`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|available|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|facility_id|INTEGER|YES|core_facility.facility_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|service_id|INTEGER|YES|ref_service.service_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_id|TEXT|YES||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_row|INTEGER|YES||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Número de fila original del Excel para lineage.|
|source_value|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||

## `core_location`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|coordinate_valid|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|exterior_number|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|facility_id|INTEGER||core_facility.facility_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|interior_number|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|is_primary|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|latitude|REAL|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|location_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|longitude|REAL|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|municipality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|postal_code|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|settlement_name|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|settlement_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|source_id|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_row|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Número de fila original del Excel para lineage.|
|state|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|street_name|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|street_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||

## `core_operating_schedule`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|days_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|facility_id|INTEGER||core_facility.facility_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|parsed_days|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|schedule_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|schedule_modality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|source_id|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_row|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Número de fila original del Excel para lineage.|

## `core_organization`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|data_confidence|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|entity_resolution_method|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|organization_domain|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|organization_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|organization_name|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|organization_name_norm|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Clave normalizada para matching/catálogos.|
|ownership_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|primary_state|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||

## `core_registration`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|cancellation_date|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|cancellation_reason|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|current_status|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|facility_id|INTEGER||core_facility.facility_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|registration_date|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|registration_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|registry_number|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||

## `core_registration_snapshot`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|cancellation_date|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|registration_id|INTEGER||core_registration.registration_id|NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|snapshot_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|snapshot_period|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|source_id|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_row|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Número de fila original del Excel para lineage.|
|status_derived|TEXT|||NO|SOURCE-BASED/TRANSFORMED|Care provider sources||
|status_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Valor fuente limpiado mínimamente; RAW original permanece disponible.|

## `core_source_record_link`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|external_record_id|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|facility_id|INTEGER||core_facility.facility_id|YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|match_confidence|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|match_method|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Care provider sources||
|organization_id|INTEGER||core_organization.organization_id|YES|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_id|TEXT|YES||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Identificador o clave foránea según entidad.|
|source_row|INTEGER|YES||NO|SOURCE-BASED/TRANSFORMED|Care provider sources|Número de fila original del Excel para lineage.|

## `gov_column_mapping`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|action|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|included_status|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|justification|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|ordinal|INTEGER|YES|gov_source_column.ordinal|NO|GOVERNANCE|Audit/model metadata||
|original_header|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|raw_column|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|raw_table|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|semantic_meaning|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|source_id|TEXT|YES|gov_source_column.source_id|NO|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|
|staging_field|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|staging_table|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|target_entity|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|target_field|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|target_table|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|transformation_rule|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|usefulness|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|validated|TEXT|||NO|GOVERNANCE|Audit/model metadata||

## `gov_column_profile`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|detected_type|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|example_1|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|example_2|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|example_3|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|non_null_count|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|null_count|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|null_pct|REAL|||YES|GOVERNANCE|Audit/model metadata||
|ordinal|INTEGER|YES|gov_source_column.ordinal|NO|GOVERNANCE|Audit/model metadata||
|quality_grade|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|source_id|TEXT|YES|gov_source_column.source_id|NO|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|
|top_values_json|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|unique_count|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|zero_token_count|INTEGER|||YES|GOVERNANCE|Audit/model metadata||

## `gov_data_dictionary`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|data_type|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|description|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|field_name|TEXT|YES||NO|GOVERNANCE|Audit/model metadata||
|fk_reference|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|nullable|INTEGER|||NO|GOVERNANCE|Audit/model metadata||
|origin_type|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|pk_flag|INTEGER|||NO|GOVERNANCE|Audit/model metadata||
|source_scope|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|table_name|TEXT|YES||NO|GOVERNANCE|Audit/model metadata||

## `gov_data_quality_issue`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|column_ordinal|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|description|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|issue_code|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|issue_id|INTEGER|YES||YES|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|
|original_value|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|severity|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|source_id|TEXT|||NO|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|
|source_row|INTEGER|||YES|GOVERNANCE|Audit/model metadata|Número de fila original del Excel para lineage.|

## `gov_entity_definition`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|entity_name|TEXT|YES||YES|GOVERNANCE|Audit/model metadata||
|layer|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|purpose|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|row_grain|TEXT|||NO|GOVERNANCE|Audit/model metadata||

## `gov_entity_match_candidate`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|candidate_facility_id|INTEGER|||YES|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|
|match_confidence|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|match_id|INTEGER|YES||YES|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|
|match_key|TEXT|||YES|GOVERNANCE|Audit/model metadata|Clave normalizada para matching/catálogos.|
|match_method|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|notes|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|source_id|TEXT|||NO|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|
|source_row|INTEGER|||NO|GOVERNANCE|Audit/model metadata|Número de fila original del Excel para lineage.|

## `gov_file_validation`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|columns_found|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|columns_mapped|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|sheets_found|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|sheets_modeled|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|source_id|TEXT|YES||YES|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|
|status|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|unmapped_columns|INTEGER|||YES|GOVERNANCE|Audit/model metadata||

## `gov_future_field_backlog`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|acquisition_method|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|future_field|TEXT|YES||YES|GOVERNANCE|Audit/model metadata||
|priority|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|reason|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|target_entity|TEXT|||NO|GOVERNANCE|Audit/model metadata||

## `gov_relationship`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|cardinality|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|child_entity|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|description|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|foreign_key|TEXT|||YES|GOVERNANCE|Audit/model metadata|Clave normalizada para matching/catálogos.|
|parent_entity|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|relationship_id|INTEGER|YES||YES|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|

## `gov_source`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|data_rows|INTEGER|||NO|GOVERNANCE|Audit/model metadata||
|data_start_row|INTEGER|||NO|GOVERNANCE|Audit/model metadata||
|declared_dimension|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|file_name|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|header_row|INTEGER|||NO|GOVERNANCE|Audit/model metadata||
|logical_columns|INTEGER|||NO|GOVERNANCE|Audit/model metadata||
|physical_max_col|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|physical_max_row|INTEGER|||YES|GOVERNANCE|Audit/model metadata||
|row_grain|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|sha256|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|sheet_name|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|source_id|TEXT|YES||YES|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|
|source_period|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|source_title|TEXT|||YES|GOVERNANCE|Audit/model metadata||

## `gov_source_column`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|excel_column|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|is_header_missing|INTEGER|||NO|GOVERNANCE|Audit/model metadata||
|normalized_header|TEXT|||YES|GOVERNANCE|Audit/model metadata||
|ordinal|INTEGER|YES||NO|GOVERNANCE|Audit/model metadata||
|original_header|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|source_id|TEXT|YES|gov_source.source_id|NO|GOVERNANCE|Audit/model metadata|Identificador o clave foránea según entidad.|

## `gov_validation_summary`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|metric|TEXT|YES||YES|GOVERNANCE|Audit/model metadata||
|status|TEXT|||NO|GOVERNANCE|Audit/model metadata||
|value|TEXT|||NO|GOVERNANCE|Audit/model metadata||

## `int_facility_profile`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|care_model|TEXT|||YES|DERIVED FIELD|Derived from CORE/STAGING||
|contactability_score|REAL|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|cross_source_count|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|current_status|TEXT|||YES|DERIVED FIELD|Derived from CORE/STAGING||
|data_completeness_score|REAL|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|data_confidence|TEXT|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|facility_complexity_score|REAL|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|facility_id|INTEGER|YES|core_facility.facility_id|YES|DERIVED FIELD|Derived from CORE/STAGING|Identificador o clave foránea según entidad.|
|has_care|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|has_email|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|has_medical|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|has_nursing|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|has_palliative|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|has_phone|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|has_rehabilitation|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|municipality|TEXT|||YES|DERIVED FIELD|Derived from CORE/STAGING||
|organization_id|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING|Identificador o clave foránea según entidad.|
|organization_name|TEXT|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|ownership_type|TEXT|||YES|DERIVED FIELD|Derived from CORE/STAGING||
|pilot_priority|TEXT|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|pilot_score|REAL|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|service_count|INTEGER|||NO|DERIVED FIELD|Derived from CORE/STAGING||
|state|TEXT|||YES|DERIVED FIELD|Derived from CORE/STAGING||

## `int_facility_service_conflict`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|dep_detected_value|INTEGER|||YES|DERIVED FIELD|Derived from CORE/STAGING||
|facility_id|INTEGER|YES||NO|DERIVED FIELD|Derived from CORE/STAGING|Identificador o clave foránea según entidad.|
|note|TEXT|||YES|DERIVED FIELD|Derived from CORE/STAGING||
|rui_jun_value|INTEGER|||YES|DERIVED FIELD|Derived from CORE/STAGING||
|service_id|INTEGER|YES||NO|DERIVED FIELD|Derived from CORE/STAGING|Identificador o clave foránea según entidad.|

## `raw_cfiev_2026h1`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|c01|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c02|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c03|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c04|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c05|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c06|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c07|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c08|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c09|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c10|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|raw_payload_json|TEXT|||NO|SOURCE-BASED FIELD|Exact source columns + source_row||
|source_row|INTEGER|YES||YES|SOURCE-BASED FIELD|Exact source columns + source_row|Número de fila original del Excel para lineage.|

## `raw_dep2025`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|c01|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c02|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c03|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c04|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c05|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c06|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c07|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c08|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c09|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c10|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c11|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c12|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c13|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c14|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c15|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c16|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c17|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c18|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c19|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c20|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c21|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c22|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|raw_payload_json|TEXT|||NO|SOURCE-BASED FIELD|Exact source columns + source_row||
|source_row|INTEGER|YES||YES|SOURCE-BASED FIELD|Exact source columns + source_row|Número de fila original del Excel para lineage.|

## `raw_diefg_2026h1`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|c01|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c02|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c03|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c04|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c05|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c06|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c07|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c08|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c09|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c10|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c11|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c12|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c13|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c14|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c15|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c16|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c17|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c18|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|raw_payload_json|TEXT|||NO|SOURCE-BASED FIELD|Exact source columns + source_row||
|source_row|INTEGER|YES||YES|SOURCE-BASED FIELD|Exact source columns + source_row|Número de fila original del Excel para lineage.|

## `raw_rui_dec2025`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|c01|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c02|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c03|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c04|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c05|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c06|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c07|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c08|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c09|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c10|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c11|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c12|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c13|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c14|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c15|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c16|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c17|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c18|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c19|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c20|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c21|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c22|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c23|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c24|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c25|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c26|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c27|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c28|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c29|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c30|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c31|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c32|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c33|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c34|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c35|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c36|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c37|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c38|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c39|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c40|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|raw_payload_json|TEXT|||NO|SOURCE-BASED FIELD|Exact source columns + source_row||
|source_row|INTEGER|YES||YES|SOURCE-BASED FIELD|Exact source columns + source_row|Número de fila original del Excel para lineage.|

## `raw_rui_jun2026`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|c01|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c02|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c03|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c04|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c05|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c06|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c07|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c08|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c09|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c10|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c11|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c12|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c13|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c14|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c15|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c16|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c17|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c18|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c19|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c20|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c21|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c22|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c23|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c24|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c25|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c26|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c27|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c28|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c29|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c30|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c31|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c32|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c33|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c34|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c35|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c36|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c37|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c38|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c39|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c40|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c41|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|c42|TEXT|||YES|SOURCE-BASED FIELD|Exact source columns + source_row||
|raw_payload_json|TEXT|||NO|SOURCE-BASED FIELD|Exact source columns + source_row||
|source_row|INTEGER|YES||YES|SOURCE-BASED FIELD|Exact source columns + source_row|Número de fila original del Excel para lineage.|

## `ref_activity`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|activity_id|INTEGER|YES||YES|CATALOG/DERIVED|Observed source categories normalized|Identificador o clave foránea según entidad.|
|activity_key|TEXT|||NO|CATALOG/DERIVED|Observed source categories normalized|Clave normalizada para matching/catálogos.|
|activity_name|TEXT|||NO|CATALOG/DERIVED|Observed source categories normalized||
|source_defined|INTEGER|||NO|CATALOG/DERIVED|Observed source categories normalized||

## `ref_municipality`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|municipality_id|INTEGER|YES||YES|CATALOG/DERIVED|Observed source categories normalized|Identificador o clave foránea según entidad.|
|municipality_key|TEXT|||NO|CATALOG/DERIVED|Observed source categories normalized|Clave normalizada para matching/catálogos.|
|municipality_name|TEXT|||NO|CATALOG/DERIVED|Observed source categories normalized||
|state_id|INTEGER||ref_state.state_id|NO|CATALOG/DERIVED|Observed source categories normalized|Identificador o clave foránea según entidad.|

## `ref_service`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|service_category|TEXT|||YES|CATALOG/DERIVED|Observed source categories normalized||
|service_id|INTEGER|YES||YES|CATALOG/DERIVED|Observed source categories normalized|Identificador o clave foránea según entidad.|
|service_key|TEXT|||NO|CATALOG/DERIVED|Observed source categories normalized|Clave normalizada para matching/catálogos.|
|service_name|TEXT|||NO|CATALOG/DERIVED|Observed source categories normalized||
|source_defined|INTEGER|||NO|CATALOG/DERIVED|Observed source categories normalized||

## `ref_state`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|state_id|INTEGER|YES||YES|CATALOG/DERIVED|Observed source categories normalized|Identificador o clave foránea según entidad.|
|state_key|TEXT|||NO|CATALOG/DERIVED|Observed source categories normalized|Clave normalizada para matching/catálogos.|
|state_name|TEXT|||NO|CATALOG/DERIVED|Observed source categories normalized||

## `research_author`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|author_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|author_name|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|author_name_norm|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Clave normalizada para matching/catálogos.|

## `research_education_contact`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|campus_id|INTEGER||research_educational_campus.campus_id|YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|contact_type|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|education_contact_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|educational_institution_id|INTEGER||research_educational_institution.educational_institution_id|NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|is_valid|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|source_id|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|source_row|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Número de fila original del Excel para lineage.|
|value_normalized|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|value_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Valor fuente limpiado mínimamente; RAW original permanece disponible.|

## `research_educational_campus`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|campus_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|campus_name|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|campus_name_norm|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Clave normalizada para matching/catálogos.|
|educational_institution_id|INTEGER||research_educational_institution.educational_institution_id|NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|exterior_number|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|municipality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|postal_code|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|settlement_name|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|settlement_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|source_id|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|source_row|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Número de fila original del Excel para lineage.|
|state|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|street_name|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|street_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||

## `research_educational_institution`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|data_confidence|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|educational_institution_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|institution_name|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|institution_name_norm|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Clave normalizada para matching/catálogos.|
|state|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|website|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||

## `research_educational_program`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|campus_id|INTEGER||research_educational_campus.campus_id|NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|education_level|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|educational_program_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|modality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|program_name|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|source_id|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|source_row|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Número de fila original del Excel para lineage.|
|study_plan_url|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||

## `research_publication`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|authors_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|edition|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|information_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|publication_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|publication_place|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|publication_year|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|publisher_or_journal|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|source_id|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|source_note_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|source_row|INTEGER|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Número de fila original del Excel para lineage.|
|title|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|title_norm|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Clave normalizada para matching/catálogos.|
|url|TEXT|||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||

## `research_publication_author`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|author_id|INTEGER|YES|research_author.author_id|NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|author_ordinal|INTEGER|YES||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|parse_confidence|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||
|publication_id|INTEGER|YES|research_publication.publication_id|NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|

## `research_publication_topic`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|publication_id|INTEGER|YES|research_publication.publication_id|NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|topic_id|INTEGER|YES|research_topic.topic_id|NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|

## `research_topic`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|topic_id|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Identificador o clave foránea según entidad.|
|topic_key|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV|Clave normalizada para matching/catálogos.|
|topic_name|TEXT|||NO|SOURCE-BASED/TRANSFORMED|DIEFG/CFIEV||

## `stg_cfiev_2026h1`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|authors_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|edition_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|information_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|information_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|is_valid_record|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|publication_place|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|publication_place_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|publication_year|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|publication_year_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|publisher|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|publisher_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|source_row|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Número de fila original del Excel para lineage.|
|title_norm|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Clave normalizada para matching/catálogos.|
|title_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|topic_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|unlabeled_j_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|url|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|url_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|

## `stg_dep2025`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|activities_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|care_model|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|care_model_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|coordinate_valid|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|days_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|email_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|exterior_number|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|exterior_number_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|external_id|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Identificador o clave foránea según entidad.|
|interior_number|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|interior_number_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|is_valid_record|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|latitude|REAL|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|latitude_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|longitude|REAL|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|longitude_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|municipality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|municipality_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|organization_name_norm|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Clave normalizada para matching/catálogos.|
|organization_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|ownership_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|ownership_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|phone1_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|phone2_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|postal_code|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|postal_code_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|schedule_modality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|schedule_modality_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|services_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|settlement_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|settlement_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|source_row|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Número de fila original del Excel para lineage.|
|state|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|state_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|street_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|street_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|

## `stg_diefg_2026h1`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|campus_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|education_level|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|education_level_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|email_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|exterior_number|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|exterior_number_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|institution_name_norm|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Clave normalizada para matching/catálogos.|
|institution_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|is_valid_record|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|modality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|modality_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|municipality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|municipality_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|phone_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|postal_code|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|postal_code_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|program_name|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|program_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|settlement_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|settlement_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|source_row|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Número de fila original del Excel para lineage.|
|state|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|state_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|street_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|street_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|study_plan_url|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|study_plan_url_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|unlabeled_r_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|website|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|website_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|

## `stg_rui_dec2025`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|care_model|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|care_model_other|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|care_model_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|email_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|is_valid_record|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|municipality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|municipality_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|organization_name_norm|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Clave normalizada para matching/catálogos.|
|organization_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|ownership_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|ownership_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|phone_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|postal_code|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|postal_code_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|registration_date|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|registration_day|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|registration_month_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|registration_year|INTEGER|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|registry_number|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_culturales|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_deportivas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_deterioro|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_fisicas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_productivas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_recreativas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_religiosas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_alimentacion|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_alojamiento_permanente|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_alojamiento_temporal|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_apoyo_juridico|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_atencion_medica|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_capacitacion|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_clases|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_cuidados|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_cuidados_paliativos|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_enfermeria|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_otros_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|service_psicologia|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_rehabilitacion|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_talleres|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_terapia_ocupacional|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_trabajo_social|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_vestido|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|settlement_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|settlement_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|site_descriptor_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|source_row|INTEGER|YES||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Número de fila original del Excel para lineage.|
|state|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|state_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|

## `stg_rui_jun2026`

|Campo|Tipo|PK|FK|Nullable|Origen|Scope|Descripción|
|---|---|---|---|---|---|---|---|
|cancellation_date|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|cancellation_date_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|care_model|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|care_model_other|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|care_model_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|email_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|is_valid_record|INT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|municipality|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|municipality_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|organization_name_norm|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Clave normalizada para matching/catálogos.|
|organization_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|ownership_type|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|ownership_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|phone_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|postal_code|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|postal_code_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|registration_date|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|registration_day|INT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|registration_month_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|registration_year|INT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|registry_number|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_culturales|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_deportivas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_deterioro|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_fisicas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_productivas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_recreativas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_actividades_religiosas|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_alimentacion|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_alojamiento_permanente|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_alojamiento_temporal|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_apoyo_juridico|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_atencion_medica|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_capacitacion|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_clases|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_cuidados|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_cuidados_paliativos|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_enfermeria|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_otros_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|service_psicologia|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_rehabilitacion|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_talleres|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_terapia_ocupacional|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_trabajo_social|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|service_vestido|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|settlement_name_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|settlement_type_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|site_descriptor_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|source_row|INT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Número de fila original del Excel para lineage.|
|state|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|state_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|
|status_derived|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source||
|status_raw|TEXT|||YES|SOURCE-BASED/TRANSFORMED|Cleaned representation of a single source|Valor fuente limpiado mínimamente; RAW original permanece disponible.|

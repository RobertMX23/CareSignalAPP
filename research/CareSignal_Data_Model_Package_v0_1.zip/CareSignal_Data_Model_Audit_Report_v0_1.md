# CareSignal — Data Model, ETL, ERD y Auditoría de Cobertura v0.1

## 1. Resultado de aceptación

**PASS.** Se procesaron 5 archivos, 5 hojas, 6,170 filas de datos y 132 columnas lógicas. Todas las columnas fueron inventariadas, perfiladas, clasificadas y mapeadas. No se eliminó ninguna columna del RAW. Dos columnas sin encabezado fueron enviadas a QUARANTINE.

```text
COVERAGE_PERCENT: 100.00 [PASS]
DROP_COLUMNS: 0 [PASS]
FILES_FOUND: 5 [PASS]
FILES_MISSING: 0 [PASS]
FILES_MODELED: 5 [PASS]
FOREIGN_KEY_ISSUES: 0 [PASS]
MAPPED_COLUMNS: 132 [PASS]
RAW_STAGE_ROW_MISMATCHES: 0 [PASS]
SHEETS_FOUND: 5 [PASS]
SHEETS_MISSING: 0 [PASS]
SHEETS_MODELED: 5 [PASS]
SOURCE_COLUMNS: 132 [PASS]
SOURCE_DATA_ROWS: 6170 [PASS]
SQLITE_INTEGRITY: OK [PASS]
STAGING_FIELD_ERRORS: 0 [PASS]
TARGET_TABLE_ERRORS: 0 [PASS]
UNMAPPED_COLUMNS: 0 [PASS]
```

La condición final solicitada se cumple: **UNMAPPED_COLUMNS = 0**.

## 2. Inventario de fuentes

|Source ID|Archivo|Hoja|Periodo|Dimensión Excel|Filas datos|Columnas lógicas|Header|Inicio datos|ROW_GRAIN|
|---|---|---|---|---|---:|---:|---:|---:|---|
|CFIEV_2026H1|CFIEV1S-2026(1).xlsx|CFITEVPS2026|2026-H1|A1:XFD735|727|10|8|9|1 fila = 1 publicación/fuente bibliográfica|
|DEP_2025|DIRECTORIO_DE_ESPACIOS_DE_PARTICIPACION_TEMPORAL_PARA_PERSONAS_ADULTAS_MAYORES_ACTUALIZACION_2025_final(1).xlsx|DEPPART2025|2025|A1:V1652|1650|22|2|3|1 fila = 1 centro/espacio físico registrado en el directorio|
|DIEFG_2026H1|DIEFG1S-2026(1).xlsx|DIEOFGPS2026|2026-H1|A1:XFC969|960|18|8|9|1 fila = 1 oferta/programa educativo en una institución/sede y modalidad|
|RUI_DEC_2025|Registrio_Unico_de_instituciones_publicas_y_privadas_que_brindan_servicios_a_personas_adultas_mayores_diciembre_2025(1).xlsx|Hoja1|2025-12|A1:AV1359|1356|40|2|4|1 fila = 1 registro RUI asociado a un establecimiento/sede en el snapshot diciembre 2025|
|RUI_JUN_2026|RegistroUnicoINPAMJunio_2026(1).xlsx|Hoja1|2026-06|A1:AV1480|1477|42|2|4|1 fila = 1 registro RUI asociado a un establecimiento/sede en el snapshot junio 2026|

**Nota sobre DIEFG y CFIEV:** Excel reporta dimensiones hasta XFC/XFD por formato aplicado a columnas vacías. La auditoría de contenido encontró solamente **18 columnas lógicas en DIEFG** y **10 en CFIEV**. Las columnas vacías por formato no se inventaron como variables.

## 3. Cobertura por archivo

|Fuente|Hojas encontradas|Hojas modeladas|Columnas encontradas|Columnas mapeadas|No mapeadas|Estado|
|---|---:|---:|---:|---:|---:|---|
|CFIEV_2026H1|1|1|10|10|0|PASS|
|DEP_2025|1|1|22|22|0|PASS|
|DIEFG_2026H1|1|1|18|18|0|PASS|
|RUI_DEC_2025|1|1|40|40|0|PASS|
|RUI_JUN_2026|1|1|42|42|0|PASS|

## 4. Decisiones columna por columna

|Acción|Columnas|
|---|---:|
|CATALOG|25|
|CHILD TABLE|48|
|KEEP|6|
|MERGE|6|
|QUARANTINE|2|
|SPLIT|14|
|TRANSFORM|31|

No hay columnas `DROP`: la política aplicada fue conservar siempre RAW. Las dos columnas sin encabezado son `QUARANTINE`, no eliminadas.

- **DIEFG columna R:** 8 URLs sin encabezado. Varias apuntan a `cmuch.edu.mx` en filas cuya institución/programa visible no permite confirmar que pertenezcan a ese registro. Se conserva íntegra y no se promueve al CORE.
- **CFIEV columna J:** 1 nota (`reportada en 2023 como concluida`) sin encabezado. Se conserva como `source_note_raw` y se marca para validación semántica.

## 5. Arquitectura implementada

```text
RAW  ->  STAGING  ->  CORE / RESEARCH  ->  INTELLIGENCE
exacto    limpio       normalizado           derivado
```

### RAW
Cada fila fuente se conserva con número de fila original y payload JSON. No se filtran bajas ni duplicados en RAW.

### STAGING
Se limpian espacios, nombres, estados, municipios, códigos postales, fechas, teléfonos, emails, URLs y coordenadas. Los valores fuente permanecen disponibles en columnas `*_raw`.

### CORE
Se separan organización, facility, ubicación, contactos, registro, snapshots longitudinales, servicios, actividades y horarios.

### RESEARCH
DIEFG y CFIEV se mantienen como dominios relacionados, no como clientes: instituciones/campus/programas educativos y publicaciones/autores/temas.

### INTELLIGENCE
`int_facility_profile` contiene variables derivadas para segmentación y pilotaje; no se confunden con datos observados.

## 6. Modelo entidad–relación

```mermaid
erDiagram
    GOV_SOURCE ||--o{ GOV_SOURCE_COLUMN : contains
    GOV_SOURCE_COLUMN ||--|| GOV_COLUMN_MAPPING : maps
    ORGANIZATION ||--o{ FACILITY : operates
    FACILITY ||--o{ LOCATION : has
    FACILITY ||--o{ CONTACT : has
    FACILITY ||--o{ REGISTRATION : registered_as
    REGISTRATION ||--o{ REGISTRATION_SNAPSHOT : observed_in
    FACILITY ||--o{ FACILITY_SERVICE_SNAPSHOT : reports
    SERVICE ||--o{ FACILITY_SERVICE_SNAPSHOT : classifies
    FACILITY ||--o{ FACILITY_SERVICE_CURRENT : current
    SERVICE ||--o{ FACILITY_SERVICE_CURRENT : classifies
    FACILITY ||--o{ FACILITY_ACTIVITY : offers
    ACTIVITY ||--o{ FACILITY_ACTIVITY : classifies
    FACILITY ||--o{ OPERATING_SCHEDULE : follows
    EDUCATIONAL_INSTITUTION ||--o{ EDUCATIONAL_CAMPUS : has
    EDUCATIONAL_CAMPUS ||--o{ EDUCATIONAL_PROGRAM : offers
    RESEARCH_PUBLICATION }o--o{ AUTHOR : authored_by
    RESEARCH_PUBLICATION }o--o{ RESEARCH_TOPIC : tagged_with
    FACILITY ||--|| FACILITY_PROFILE : summarized_as
```

Principio clave: **ORGANIZATION != FACILITY**. Una organización puede tener múltiples sedes. Además, `REGISTRATION_SNAPSHOT` evita sobrescribir diciembre 2025 con junio 2026.

## 7. Resultado ETL / transcripción limpia

|Entidad / tabla|Filas|
|---|---:|
|Organizaciones de cuidado|2,418|
|Facilities/centros|3,026|
|Registros RUI|1,477|
|Snapshots RUI|2,833|
|Ubicaciones observadas|4,483|
|Contactos normalizados|7,528|
|Servicios actuales facility-servicio|38,174|
|Evidencias históricas de servicios|70,280|
|Actividades|7,818|
|Horarios|1,650|
|Instituciones educativas (institución+estado)|237|
|Nombres educativos únicos|145|
|Campus educativos|536|
|Programas educativos|960|
|Publicaciones|727|
|Autores candidatos parseados|1,444|
|Temas normalizados|43|
|Facility profiles|3,026|

## 8. Longitudinalidad RUI

- Diciembre 2025: **1,356** registros.
- Junio 2026: **1,477** registros.
- Coincidencias por `registry_number`: **1,356**.
- Nuevos en junio: **121**.
- De diciembre no encontrados en junio: **0**.
- Estado junio 2026: **1,373 ACTIVE**, **91 INACTIVE**, **13 DUPLICATE_INACTIVE**.
Esto justifica una entidad `REGISTRATION` más una tabla `REGISTRATION_SNAPSHOT`, no dos tablas maestras independientes.

## 9. Entity resolution entre RUI y Directorio temporal

- Se realizaron fusiones automáticas únicamente con **nombre normalizado + estado + municipio** cuando existía un único candidato RUI.
- Coincidencias exactas de alta confianza: **101 filas DEP**.
- Registros DEP no fusionados automáticamente: **1,549**.
- Se detectaron **4 candidatos ambiguos** en los que había más de una facility RUI compatible; se conservaron como candidatos, no como unión forzada.
La siguiente fase puede añadir fuzzy matching por dirección, teléfono, CP y coordenadas, pero debe mantener los matches ambiguos separados.

## 10. Calidad y limpieza

|Issue detectado|Casos registrados en log|
|---|---:|
|ZERO_AS_MISSING|549|
|UNLABELED_POPULATED_COLUMN|9|
|INVALID_SERVICE_FLAG|8|
|INVALID_EMAIL|3|
|MISSING_HEADER|2|
|INVALID_OR_MISSING_COORDINATE|2|

El log no intenta convertir cada ausencia normal en un error. La completitud exacta por columna está en `gov_column_profile`.

Hallazgos destacados:
- DEP: `NO. EXT = 0` aparece 773 veces; `NO. INT = 0` aparece 1,618 veces. En STAGING se interpreta 0 como ausencia, pero RAW conserva el cero.
- DEP: `TELEFONO 1 = 0` aparece 549 veces y `TELEFONO 2 = 0` 1,582 veces; no deben considerarse teléfonos reales.
- DEP: 1,649 filas tienen valores de latitud/longitud; **1,648 pasan la validación de rango México**, por lo que hay un caso inválido además del faltante.
- RUI dic-2025: `VESTIDO` contiene 5 valores `0` y `ACTIVIDADES PRODUCTIVAS` 3 valores `0`; se marcan como banderas no estándar.
- `SEDE` en RUI mezcla nombres de sede y descriptores que parecen direcciones; por eso se conserva como `site_descriptor_raw` y no se interpreta automáticamente.

## 11. Qué columnas sí sirven y cuáles no pasan al CORE

**CORE:** identificadores, fechas, modalidad, institución, ubicación, CP, contactos, propiedad, servicios, bajas, coordenadas, horarios, programas y metadatos bibliográficos.

**SUPPORTING:** tipo de vialidad/asentamiento, edición, descripción de modalidad `OTRO`, etc.

**QUARANTINE:** solo las dos columnas sin encabezado. No hay `DROP` físico.

## 12. Campos futuros: NO existen en los archivos

El modelo diferencia `SOURCE-BASED`, `DERIVED` y `FUTURE`. Los siguientes datos no se inventaron: capacidad, ocupación, residentes, cuidadores, turnos, software, rondas, incidentes, auditorías, comunicación familiar, precio y decisor.

|Campo futuro|Entidad|Prioridad|Cómo obtenerlo|
|---|---|---|---|
|capacity_residents|FACILITY|CRITICAL|Web + entrevista + piloto|
|caregiver_count|FACILITY|CRITICAL|Entrevista/piloto|
|current_occupancy|FACILITY|CRITICAL|Entrevista/piloto|
|current_software|FACILITY|CRITICAL|Entrevista|
|decision_maker_name|ORGANIZATION|CRITICAL|Web + llamada|
|decision_maker_role|ORGANIZATION|CRITICAL|Web + llamada|
|family_communication_process|FACILITY|CRITICAL|Entrevista|
|pilot_willingness|ORGANIZATION|CRITICAL|Customer discovery|
|resident_count|FACILITY|CRITICAL|Entrevista/piloto|
|rounds_process|FACILITY|CRITICAL|Entrevista/observación|
|audit_requirements|FACILITY|HIGH|Entrevista/documentos|
|incident_process|FACILITY|HIGH|Entrevista/observación|
|shift_structure|FACILITY|HIGH|Entrevista|
|website_verified|ORGANIZATION|HIGH|Web enrichment|
|monthly_price_range|FACILITY|MEDIUM|Web + entrevista|
|staff_count|ORGANIZATION|MEDIUM|Web/entrevista|

## 13. Validación final obligatoria

> ¿Existe alguna columna, hoja, archivo, categoría o tipo de información de las fuentes originales que no esté representada, mapeada, conservada en RAW o explícitamente descartada con justificación dentro del Data Model de CareSignal?

**Respuesta: NO, para las variables lógicas con contenido detectadas en los cinco archivos.**

- 5/5 archivos modelados.
- 5/5 hojas modeladas.
- 132/132 columnas lógicas inventariadas.
- 132/132 columnas clasificadas y mapeadas.
- 0 columnas no mapeadas.
- 0 errores de referencia a campos STAGING.
- 0 errores de referencia a tablas destino.
- 0 diferencias entre filas RAW y STAGING.
- 0 columnas eliminadas físicamente.
- 2 columnas sin encabezado preservadas en QUARANTINE.
- SQLite `integrity_check = ok`.
- 0 violaciones de foreign keys.

## 14. Archivos de entrega

- `CareSignal_Data_Model_Master_v0_1.sqlite`: base ejecutable con RAW, STAGING, CORE, RESEARCH, INTELLIGENCE y GOVERNANCE.
- `CareSignal_Column_Coverage_Matrix_v0_1.md`: auditoría completa columna por columna.
- `CareSignal_Data_Dictionary_v0_1.md`: diccionario completo del modelo.
- `CareSignal_Data_Model_DDL_v0_1.sql`: DDL reproducible.
- `CareSignal_ERD_v0_1.mmd`: diagrama Mermaid.

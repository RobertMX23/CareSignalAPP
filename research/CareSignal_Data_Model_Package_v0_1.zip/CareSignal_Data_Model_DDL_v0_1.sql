-- CareSignal Data Model v0.1
-- Generated from five INAPAM-related Excel sources.

CREATE TABLE core_contact (
 contact_id INTEGER PRIMARY KEY AUTOINCREMENT,
 facility_id INTEGER,
 organization_id INTEGER,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 contact_type TEXT NOT NULL,
 value_raw TEXT,
 value_normalized TEXT,
 is_valid INTEGER NOT NULL,
 FOREIGN KEY(facility_id) REFERENCES core_facility(facility_id),
 FOREIGN KEY(organization_id) REFERENCES core_organization(organization_id)
);

CREATE TABLE core_facility (
 facility_id INTEGER PRIMARY KEY AUTOINCREMENT,
 organization_id INTEGER NOT NULL,
 facility_name TEXT,
 site_descriptor_raw TEXT,
 facility_type TEXT,
 care_model TEXT,
 care_model_other TEXT,
 current_status TEXT,
 primary_source_id TEXT,
 data_confidence TEXT NOT NULL,
 FOREIGN KEY(organization_id) REFERENCES core_organization(organization_id)
);

CREATE TABLE core_facility_activity (
 facility_id INTEGER NOT NULL,
 activity_id INTEGER NOT NULL,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 source_value TEXT,
 PRIMARY KEY(facility_id,activity_id,source_id,source_row),
 FOREIGN KEY(facility_id) REFERENCES core_facility(facility_id),
 FOREIGN KEY(activity_id) REFERENCES ref_activity(activity_id)
);

CREATE TABLE core_facility_service_current (
 facility_id INTEGER NOT NULL,
 service_id INTEGER NOT NULL,
 available INTEGER NOT NULL,
 preferred_source_id TEXT NOT NULL,
 confidence TEXT NOT NULL,
 PRIMARY KEY(facility_id,service_id),
 FOREIGN KEY(facility_id) REFERENCES core_facility(facility_id),
 FOREIGN KEY(service_id) REFERENCES ref_service(service_id)
);

CREATE TABLE core_facility_service_snapshot (
 facility_id INTEGER NOT NULL,
 service_id INTEGER NOT NULL,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 available INTEGER,
 source_value TEXT,
 PRIMARY KEY(facility_id,service_id,source_id,source_row),
 FOREIGN KEY(facility_id) REFERENCES core_facility(facility_id),
 FOREIGN KEY(service_id) REFERENCES ref_service(service_id)
);

CREATE TABLE core_location (
 location_id INTEGER PRIMARY KEY AUTOINCREMENT,
 facility_id INTEGER NOT NULL,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 street_type TEXT,
 street_name TEXT,
 exterior_number TEXT,
 interior_number TEXT,
 settlement_type TEXT,
 settlement_name TEXT,
 municipality TEXT,
 state TEXT,
 postal_code TEXT,
 latitude REAL,
 longitude REAL,
 coordinate_valid INTEGER,
 is_primary INTEGER NOT NULL DEFAULT 0,
 FOREIGN KEY(facility_id) REFERENCES core_facility(facility_id)
);

CREATE TABLE core_operating_schedule (
 schedule_id INTEGER PRIMARY KEY AUTOINCREMENT,
 facility_id INTEGER NOT NULL,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 days_raw TEXT,
 parsed_days TEXT,
 schedule_modality TEXT,
 FOREIGN KEY(facility_id) REFERENCES core_facility(facility_id)
);

CREATE TABLE core_organization (
 organization_id INTEGER PRIMARY KEY AUTOINCREMENT,
 organization_name TEXT NOT NULL,
 organization_name_norm TEXT NOT NULL,
 ownership_type TEXT,
 primary_state TEXT,
 organization_domain TEXT NOT NULL DEFAULT 'CARE_PROVIDER',
 entity_resolution_method TEXT NOT NULL,
 data_confidence TEXT NOT NULL,
 UNIQUE(organization_name_norm, primary_state, ownership_type)
);

CREATE TABLE core_registration (
 registration_id INTEGER PRIMARY KEY AUTOINCREMENT,
 registry_number TEXT NOT NULL UNIQUE,
 facility_id INTEGER NOT NULL,
 registration_date TEXT,
 current_status TEXT,
 cancellation_date TEXT,
 cancellation_reason TEXT,
 FOREIGN KEY(facility_id) REFERENCES core_facility(facility_id)
);

CREATE TABLE core_registration_snapshot (
 snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT,
 registration_id INTEGER NOT NULL,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 snapshot_period TEXT NOT NULL,
 status_raw TEXT,
 status_derived TEXT NOT NULL,
 cancellation_date TEXT,
 FOREIGN KEY(registration_id) REFERENCES core_registration(registration_id)
);

CREATE TABLE core_source_record_link (
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 external_record_id TEXT,
 organization_id INTEGER,
 facility_id INTEGER,
 match_method TEXT,
 match_confidence TEXT,
 PRIMARY KEY(source_id, source_row),
 FOREIGN KEY(organization_id) REFERENCES core_organization(organization_id),
 FOREIGN KEY(facility_id) REFERENCES core_facility(facility_id)
);

CREATE TABLE gov_column_mapping (
  source_id TEXT NOT NULL,
  ordinal INTEGER NOT NULL,
  original_header TEXT NOT NULL,
  semantic_meaning TEXT NOT NULL,
  usefulness TEXT NOT NULL,
  action TEXT NOT NULL,
  raw_table TEXT NOT NULL,
  raw_column TEXT NOT NULL,
  staging_table TEXT NOT NULL,
  staging_field TEXT,
  target_entity TEXT,
  target_table TEXT,
  target_field TEXT,
  transformation_rule TEXT,
  justification TEXT,
  included_status TEXT NOT NULL,
  validated TEXT NOT NULL,
  PRIMARY KEY(source_id, ordinal),
  FOREIGN KEY(source_id,ordinal) REFERENCES gov_source_column(source_id,ordinal)
);

CREATE TABLE gov_column_profile (
  source_id TEXT NOT NULL,
  ordinal INTEGER NOT NULL,
  detected_type TEXT,
  non_null_count INTEGER,
  null_count INTEGER,
  null_pct REAL,
  zero_token_count INTEGER,
  unique_count INTEGER,
  example_1 TEXT,
  example_2 TEXT,
  example_3 TEXT,
  top_values_json TEXT,
  quality_grade TEXT,
  PRIMARY KEY(source_id, ordinal),
  FOREIGN KEY(source_id,ordinal) REFERENCES gov_source_column(source_id,ordinal)
);

CREATE TABLE gov_data_dictionary (
 table_name TEXT NOT NULL,
 field_name TEXT NOT NULL,
 data_type TEXT,
 pk_flag INTEGER NOT NULL,
 fk_reference TEXT,
 nullable INTEGER NOT NULL,
 origin_type TEXT NOT NULL,
 source_scope TEXT,
 description TEXT,
 PRIMARY KEY(table_name, field_name)
);

CREATE TABLE gov_data_quality_issue (
  issue_id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id TEXT NOT NULL,
  source_row INTEGER,
  column_ordinal INTEGER,
  issue_code TEXT NOT NULL,
  severity TEXT NOT NULL,
  original_value TEXT,
  description TEXT NOT NULL
);

CREATE TABLE gov_entity_definition (
 entity_name TEXT PRIMARY KEY,
 layer TEXT NOT NULL,
 purpose TEXT NOT NULL,
 row_grain TEXT NOT NULL
);

CREATE TABLE gov_entity_match_candidate (
  match_id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id TEXT NOT NULL,
  source_row INTEGER NOT NULL,
  candidate_facility_id INTEGER,
  match_method TEXT NOT NULL,
  match_confidence TEXT NOT NULL,
  match_key TEXT,
  notes TEXT
);

CREATE TABLE gov_file_validation (
  source_id TEXT PRIMARY KEY,
  sheets_found INTEGER,
  sheets_modeled INTEGER,
  columns_found INTEGER,
  columns_mapped INTEGER,
  unmapped_columns INTEGER,
  status TEXT
);

CREATE TABLE gov_future_field_backlog (
 future_field TEXT PRIMARY KEY,
 target_entity TEXT NOT NULL,
 priority TEXT NOT NULL,
 acquisition_method TEXT NOT NULL,
 reason TEXT NOT NULL
);

CREATE TABLE gov_relationship (
 relationship_id INTEGER PRIMARY KEY AUTOINCREMENT,
 parent_entity TEXT NOT NULL,
 child_entity TEXT NOT NULL,
 cardinality TEXT NOT NULL,
 foreign_key TEXT,
 description TEXT
);

CREATE TABLE gov_source (
  source_id TEXT PRIMARY KEY,
  file_name TEXT NOT NULL,
  sheet_name TEXT NOT NULL,
  source_period TEXT,
  source_title TEXT,
  declared_dimension TEXT,
  physical_max_row INTEGER,
  physical_max_col INTEGER,
  data_rows INTEGER NOT NULL,
  logical_columns INTEGER NOT NULL,
  header_row INTEGER NOT NULL,
  data_start_row INTEGER NOT NULL,
  row_grain TEXT NOT NULL,
  sha256 TEXT NOT NULL
);

CREATE TABLE gov_source_column (
  source_id TEXT NOT NULL,
  ordinal INTEGER NOT NULL,
  excel_column TEXT NOT NULL,
  original_header TEXT NOT NULL,
  normalized_header TEXT,
  is_header_missing INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (source_id, ordinal),
  FOREIGN KEY(source_id) REFERENCES gov_source(source_id)
);

CREATE TABLE gov_validation_summary (
  metric TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE int_facility_profile (
 facility_id INTEGER PRIMARY KEY,
 organization_id INTEGER NOT NULL,
 organization_name TEXT NOT NULL,
 ownership_type TEXT,
 care_model TEXT,
 current_status TEXT,
 state TEXT,
 municipality TEXT,
 service_count INTEGER NOT NULL,
 has_nursing INTEGER NOT NULL,
 has_care INTEGER NOT NULL,
 has_medical INTEGER NOT NULL,
 has_palliative INTEGER NOT NULL,
 has_rehabilitation INTEGER NOT NULL,
 has_phone INTEGER NOT NULL,
 has_email INTEGER NOT NULL,
 cross_source_count INTEGER NOT NULL,
 data_completeness_score REAL NOT NULL,
 facility_complexity_score REAL NOT NULL,
 contactability_score REAL NOT NULL,
 pilot_score REAL NOT NULL,
 pilot_priority TEXT NOT NULL,
 data_confidence TEXT NOT NULL,
 FOREIGN KEY(facility_id) REFERENCES core_facility(facility_id)
);

CREATE TABLE int_facility_service_conflict (
 facility_id INTEGER NOT NULL,
 service_id INTEGER NOT NULL,
 rui_jun_value INTEGER,
 dep_detected_value INTEGER,
 note TEXT,
 PRIMARY KEY(facility_id,service_id)
);

CREATE TABLE raw_cfiev_2026h1 (source_row INTEGER PRIMARY KEY, c01 TEXT, c02 TEXT, c03 TEXT, c04 TEXT, c05 TEXT, c06 TEXT, c07 TEXT, c08 TEXT, c09 TEXT, c10 TEXT, raw_payload_json TEXT NOT NULL);

CREATE TABLE raw_dep2025 (source_row INTEGER PRIMARY KEY, c01 TEXT, c02 TEXT, c03 TEXT, c04 TEXT, c05 TEXT, c06 TEXT, c07 TEXT, c08 TEXT, c09 TEXT, c10 TEXT, c11 TEXT, c12 TEXT, c13 TEXT, c14 TEXT, c15 TEXT, c16 TEXT, c17 TEXT, c18 TEXT, c19 TEXT, c20 TEXT, c21 TEXT, c22 TEXT, raw_payload_json TEXT NOT NULL);

CREATE TABLE raw_diefg_2026h1 (source_row INTEGER PRIMARY KEY, c01 TEXT, c02 TEXT, c03 TEXT, c04 TEXT, c05 TEXT, c06 TEXT, c07 TEXT, c08 TEXT, c09 TEXT, c10 TEXT, c11 TEXT, c12 TEXT, c13 TEXT, c14 TEXT, c15 TEXT, c16 TEXT, c17 TEXT, c18 TEXT, raw_payload_json TEXT NOT NULL);

CREATE TABLE raw_rui_dec2025 (source_row INTEGER PRIMARY KEY, c01 TEXT, c02 TEXT, c03 TEXT, c04 TEXT, c05 TEXT, c06 TEXT, c07 TEXT, c08 TEXT, c09 TEXT, c10 TEXT, c11 TEXT, c12 TEXT, c13 TEXT, c14 TEXT, c15 TEXT, c16 TEXT, c17 TEXT, c18 TEXT, c19 TEXT, c20 TEXT, c21 TEXT, c22 TEXT, c23 TEXT, c24 TEXT, c25 TEXT, c26 TEXT, c27 TEXT, c28 TEXT, c29 TEXT, c30 TEXT, c31 TEXT, c32 TEXT, c33 TEXT, c34 TEXT, c35 TEXT, c36 TEXT, c37 TEXT, c38 TEXT, c39 TEXT, c40 TEXT, raw_payload_json TEXT NOT NULL);

CREATE TABLE raw_rui_jun2026 (source_row INTEGER PRIMARY KEY, c01 TEXT, c02 TEXT, c03 TEXT, c04 TEXT, c05 TEXT, c06 TEXT, c07 TEXT, c08 TEXT, c09 TEXT, c10 TEXT, c11 TEXT, c12 TEXT, c13 TEXT, c14 TEXT, c15 TEXT, c16 TEXT, c17 TEXT, c18 TEXT, c19 TEXT, c20 TEXT, c21 TEXT, c22 TEXT, c23 TEXT, c24 TEXT, c25 TEXT, c26 TEXT, c27 TEXT, c28 TEXT, c29 TEXT, c30 TEXT, c31 TEXT, c32 TEXT, c33 TEXT, c34 TEXT, c35 TEXT, c36 TEXT, c37 TEXT, c38 TEXT, c39 TEXT, c40 TEXT, c41 TEXT, c42 TEXT, raw_payload_json TEXT NOT NULL);

CREATE TABLE ref_activity (
 activity_id INTEGER PRIMARY KEY AUTOINCREMENT,
 activity_name TEXT NOT NULL,
 activity_key TEXT NOT NULL UNIQUE,
 source_defined INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE ref_municipality (
 municipality_id INTEGER PRIMARY KEY AUTOINCREMENT,
 state_id INTEGER NOT NULL,
 municipality_name TEXT NOT NULL,
 municipality_key TEXT NOT NULL,
 UNIQUE(state_id, municipality_key),
 FOREIGN KEY(state_id) REFERENCES ref_state(state_id)
);

CREATE TABLE ref_service (
 service_id INTEGER PRIMARY KEY AUTOINCREMENT,
 service_name TEXT NOT NULL,
 service_key TEXT NOT NULL UNIQUE,
 service_category TEXT,
 source_defined INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE ref_state (
 state_id INTEGER PRIMARY KEY AUTOINCREMENT,
 state_name TEXT NOT NULL UNIQUE,
 state_key TEXT NOT NULL UNIQUE
);

CREATE TABLE research_author (
 author_id INTEGER PRIMARY KEY AUTOINCREMENT,
 author_name TEXT NOT NULL,
 author_name_norm TEXT NOT NULL UNIQUE
);

CREATE TABLE research_education_contact (
 education_contact_id INTEGER PRIMARY KEY AUTOINCREMENT,
 educational_institution_id INTEGER NOT NULL,
 campus_id INTEGER,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 contact_type TEXT NOT NULL,
 value_raw TEXT,
 value_normalized TEXT,
 is_valid INTEGER NOT NULL,
 FOREIGN KEY(educational_institution_id) REFERENCES research_educational_institution(educational_institution_id),
 FOREIGN KEY(campus_id) REFERENCES research_educational_campus(campus_id)
);

CREATE TABLE research_educational_campus (
 campus_id INTEGER PRIMARY KEY AUTOINCREMENT,
 educational_institution_id INTEGER NOT NULL,
 campus_name TEXT,
 campus_name_norm TEXT,
 state TEXT,
 municipality TEXT,
 street_type TEXT,
 street_name TEXT,
 exterior_number TEXT,
 settlement_type TEXT,
 settlement_name TEXT,
 postal_code TEXT,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 FOREIGN KEY(educational_institution_id) REFERENCES research_educational_institution(educational_institution_id)
);

CREATE TABLE research_educational_institution (
 educational_institution_id INTEGER PRIMARY KEY AUTOINCREMENT,
 institution_name TEXT NOT NULL,
 institution_name_norm TEXT NOT NULL,
 state TEXT,
 website TEXT,
 data_confidence TEXT NOT NULL,
 UNIQUE(institution_name_norm,state)
);

CREATE TABLE research_educational_program (
 educational_program_id INTEGER PRIMARY KEY AUTOINCREMENT,
 campus_id INTEGER NOT NULL,
 education_level TEXT,
 program_name TEXT,
 modality TEXT,
 study_plan_url TEXT,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL,
 FOREIGN KEY(campus_id) REFERENCES research_educational_campus(campus_id)
);

CREATE TABLE research_publication (
 publication_id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 title_norm TEXT NOT NULL,
 authors_raw TEXT,
 publication_place TEXT,
 publication_year INTEGER,
 publisher_or_journal TEXT,
 edition TEXT,
 information_type TEXT,
 url TEXT,
 source_note_raw TEXT,
 source_id TEXT NOT NULL,
 source_row INTEGER NOT NULL
);

CREATE TABLE research_publication_author (
 publication_id INTEGER NOT NULL,
 author_id INTEGER NOT NULL,
 author_ordinal INTEGER NOT NULL,
 parse_confidence TEXT NOT NULL,
 PRIMARY KEY(publication_id,author_id,author_ordinal),
 FOREIGN KEY(publication_id) REFERENCES research_publication(publication_id),
 FOREIGN KEY(author_id) REFERENCES research_author(author_id)
);

CREATE TABLE research_publication_topic (
 publication_id INTEGER NOT NULL,
 topic_id INTEGER NOT NULL,
 PRIMARY KEY(publication_id,topic_id),
 FOREIGN KEY(publication_id) REFERENCES research_publication(publication_id),
 FOREIGN KEY(topic_id) REFERENCES research_topic(topic_id)
);

CREATE TABLE research_topic (
 topic_id INTEGER PRIMARY KEY AUTOINCREMENT,
 topic_name TEXT NOT NULL,
 topic_key TEXT NOT NULL UNIQUE
);

CREATE TABLE stg_cfiev_2026h1 (
 source_row INTEGER PRIMARY KEY, title_raw TEXT, title_norm TEXT, authors_raw TEXT, topic_raw TEXT, publication_place_raw TEXT,
 publication_place TEXT, publication_year_raw TEXT, publication_year INTEGER, publisher_raw TEXT, publisher TEXT,
 edition_raw TEXT, information_type_raw TEXT, information_type TEXT, url_raw TEXT, url TEXT, unlabeled_j_raw TEXT,
 is_valid_record INTEGER
);

CREATE TABLE stg_dep2025 (
 source_row INTEGER PRIMARY KEY, external_id TEXT, care_model_raw TEXT, care_model TEXT, organization_name_raw TEXT,
 organization_name_norm TEXT, state_raw TEXT, state TEXT, municipality_raw TEXT, municipality TEXT, street_type_raw TEXT,
 street_name_raw TEXT, exterior_number_raw TEXT, exterior_number TEXT, interior_number_raw TEXT, interior_number TEXT,
 settlement_type_raw TEXT, settlement_name_raw TEXT, postal_code_raw TEXT, postal_code TEXT, phone1_raw TEXT,
 phone2_raw TEXT, email_raw TEXT, ownership_type_raw TEXT, ownership_type TEXT, days_raw TEXT, schedule_modality_raw TEXT,
 schedule_modality TEXT, services_raw TEXT, activities_raw TEXT, latitude_raw TEXT, latitude REAL, longitude_raw TEXT,
 longitude REAL, coordinate_valid INTEGER, is_valid_record INTEGER
);

CREATE TABLE stg_diefg_2026h1 (
 source_row INTEGER PRIMARY KEY, institution_name_raw TEXT, institution_name_norm TEXT, campus_name_raw TEXT, state_raw TEXT,
 state TEXT, municipality_raw TEXT, municipality TEXT, street_type_raw TEXT, street_name_raw TEXT, exterior_number_raw TEXT,
 exterior_number TEXT, settlement_type_raw TEXT, settlement_name_raw TEXT, postal_code_raw TEXT, postal_code TEXT,
 phone_raw TEXT, email_raw TEXT, website_raw TEXT, website TEXT, education_level_raw TEXT, education_level TEXT,
 program_name_raw TEXT, program_name TEXT, modality_raw TEXT, modality TEXT, study_plan_url_raw TEXT, study_plan_url TEXT,
 unlabeled_r_raw TEXT, is_valid_record INTEGER
);

CREATE TABLE stg_rui_dec2025 (
 source_row INTEGER PRIMARY KEY, registry_number TEXT, registration_year INTEGER, registration_month_raw TEXT,
 registration_day INTEGER, registration_date TEXT, care_model_raw TEXT, care_model TEXT, care_model_other TEXT,
 organization_name_raw TEXT, organization_name_norm TEXT, site_descriptor_raw TEXT, state_raw TEXT, state TEXT,
 municipality_raw TEXT, municipality TEXT, settlement_type_raw TEXT, settlement_name_raw TEXT, postal_code_raw TEXT,
 postal_code TEXT, phone_raw TEXT, email_raw TEXT, ownership_type_raw TEXT, ownership_type TEXT,
 service_alojamiento_permanente TEXT, service_alojamiento_temporal TEXT, service_alimentacion TEXT, service_vestido TEXT,
 service_atencion_medica TEXT, service_enfermeria TEXT, service_cuidados TEXT, service_cuidados_paliativos TEXT,
 service_rehabilitacion TEXT, service_psicologia TEXT, service_trabajo_social TEXT, service_terapia_ocupacional TEXT,
 service_apoyo_juridico TEXT, service_actividades_fisicas TEXT, service_actividades_deportivas TEXT,
 service_actividades_culturales TEXT, service_actividades_recreativas TEXT, service_actividades_productivas TEXT,
 service_actividades_deterioro TEXT, service_actividades_religiosas TEXT, service_clases TEXT, service_talleres TEXT,
 service_capacitacion TEXT, service_otros_raw TEXT, is_valid_record INTEGER
);

CREATE TABLE stg_rui_jun2026(
  source_row INT,
  registry_number TEXT,
  registration_year INT,
  registration_month_raw TEXT,
  registration_day INT,
  registration_date TEXT,
  care_model_raw TEXT,
  care_model TEXT,
  care_model_other TEXT,
  organization_name_raw TEXT,
  organization_name_norm TEXT,
  site_descriptor_raw TEXT,
  state_raw TEXT,
  state TEXT,
  municipality_raw TEXT,
  municipality TEXT,
  settlement_type_raw TEXT,
  settlement_name_raw TEXT,
  postal_code_raw TEXT,
  postal_code TEXT,
  phone_raw TEXT,
  email_raw TEXT,
  ownership_type_raw TEXT,
  ownership_type TEXT,
  service_alojamiento_permanente TEXT,
  service_alojamiento_temporal TEXT,
  service_alimentacion TEXT,
  service_vestido TEXT,
  service_atencion_medica TEXT,
  service_enfermeria TEXT,
  service_cuidados TEXT,
  service_cuidados_paliativos TEXT,
  service_rehabilitacion TEXT,
  service_psicologia TEXT,
  service_trabajo_social TEXT,
  service_terapia_ocupacional TEXT,
  service_apoyo_juridico TEXT,
  service_actividades_fisicas TEXT,
  service_actividades_deportivas TEXT,
  service_actividades_culturales TEXT,
  service_actividades_recreativas TEXT,
  service_actividades_productivas TEXT,
  service_actividades_deterioro TEXT,
  service_actividades_religiosas TEXT,
  service_clases TEXT,
  service_talleres TEXT,
  service_capacitacion TEXT,
  service_otros_raw TEXT,
  is_valid_record INT
, status_raw TEXT, status_derived TEXT, cancellation_date_raw TEXT, cancellation_date TEXT);


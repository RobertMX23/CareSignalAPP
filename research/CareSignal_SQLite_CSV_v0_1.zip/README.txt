CareSignal SQLite -> CSV export v0.1

Source database: CareSignal_Data_Model_Master_v0_1.sqlite
Tables exported: 48
Encoding: UTF-8 with BOM (Excel-friendly)
One CSV per SQLite table. No tables were merged or omitted.

Folders:
01_RAW          Original source-preservation tables
02_STAGING      Cleaned/typed staging tables
03_CORE         Normalized operational entities
04_REFERENCE    Catalog/reference tables
05_RESEARCH     Education/publication ecosystem tables
06_INTELLIGENCE Derived analytical profiles
07_GOVERNANCE   Mapping, dictionary, quality, and validation tables

manifest.csv contains row/column counts and SHA-256 checksums.
sqlite_schema_columns.csv contains the SQLite column definitions.
